var o = Object();
o = {
"to brush ones teeth    " : "刷 牙    (  shuā yá   )",
"to cook food     " : "做 饭    (  zuò fàn   )",
"to do laundry    " : "洗 衣 服    (  xǐ yī fú   )",
"to drive a car    ":"开 车    (  kāi chē   )",    
"to eat, to have a meal    " : "吃 饭    (  chī fàn   )",
"to get dressed    " : "穿 衣 服  (  chuān yī fú  )",
"to get up    " : "起 床    (  qǐ chuáng   )",
"to go to school" : "上 学    (  shàng xué   )",
"to go to the bathroom    " : "上 厕 所    (  shàng cè suǒ   )",
"to go to work    " : "上 班    (  shàng bān   )",
"to ride a bicycle    " : "骑 自 行 车    (  qí zì xíng chē  )",
"to sleep    " : "睡 觉   (  shuì jiào  )",
"to take a bath or shower    " : "洗 澡    (  xǐ zǎo   )",
"to wash face" : "洗 脸   (  xǐ liǎn   )"
}; 


