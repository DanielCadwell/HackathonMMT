 function initKeysVals (o){
   myKeys = [];  myVals = [];
	 counter = 0; // forwardFlag ? 0 : myKeys.length - 1;  // moved here from after this fcn 4/16/12
	 keyFlag = false;  // forwardFlag ? false : true;
   for( aKey in o){
	// document.writeln(o[aKey]+"-->"+aKey+"<p>");
	  myKeys.push(aKey);
	  myVals.push(o[aKey]);
   }
} // end initKeysVals()  fcn