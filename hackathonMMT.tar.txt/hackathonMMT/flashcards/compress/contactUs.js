// contactUs.js   1/16/13
$(document).ready(function(){
 function textareaFocus(){
 //  alert(secondForm.elements[0].value);
  if (secondForm.elements[0].value=="Send us a comment or question"){
	secondForm.elements[0].value="";
  }
 } // end fcn text area focus

 var edsAlreadySubmitted2 = false;
 function validateForm(){    // second form to send a message
    if( edsAlreadySubmitted2) { return false; }   // only allow sending one message
    var x=document.forms["secondForm"]["myQuestion"].value;
    if (x==null || x==""|| x == "Send us a comment or question") {
    alert("Please enter a question or comment");
    return false;
     } // end if
      $("#myResponse2").load("/php/contactUs.php", $("#secondForm").serializeArray());
      edsAlreadySubmitted2 = true;
           $("#myResponse2").animate({
                  fontSize:"16pt"
               //   fontColor: "red",
		 //   borderWidth:"11px"
             }, 1000);
             $("#myResponse2").animate({
                  fontSize:"12pt"
            }, 1000);
  } // end validate Form
 $("#myButton2").bind('click',validateForm);
 $("#myQuestion").bind('click',textareaFocus);
});  // end ready