//  this is /js/flashcards/simplified-activities.js   <script type="text/javascript">
			$(function(){	
				$("#flipPad a").bind("click",function(){
					var $this = $(this);
					// var myResults = [];
					var myResults = myFlasher();
					var myColor = myResults.myColor;
					var myContent = myResults.myContent;
					$("#flipbox").flip({
						direction:  $this.attr("rel"),
						color: myColor,  // "red",   // $this.attr("rev"),
						content: myContent    //  $this.attr("title"),//(new Date()).getTime(),
						//  onBefore: function(){$(".revert").show()}
					})
		   	                     return false;
				});	
			});   // end $.ready
    var englishFirst = true;
var o = Object();
o = {
"to get up    " : "起 床    (  qǐ chuáng   )",
"to brush ones teeth    " : "刷 牙    (  shuā yá   )",
"to wash face" : "洗 脸   (  xǐ liǎn   )",
"to get dressed    " : "穿 衣 服  (  chuān yī fú  )",
"to cook food     " : "做 饭    (  zuò fàn   )",
"to eat, to have a meal    " : "吃 饭    (  chī fàn   )",
"to drive a car    ":"开 车    (  kāi chē   )",    
"to go to work    " : "上 班    (  shàng bān   )",
"to ride a bicycle    " : "骑 自 行 车    (  qí zì xíng chē  )",
"to go to school" : "上 学    (  shàng xué   )",
"to go to the bathroom    " : "上 厕 所    (  shàng cè suǒ   )",
"to take a bath or shower    " : "洗 澡    (  xǐ zǎo   )",
"to do laundry    " : "洗 衣 服    (  xǐ yī fú   )",
"to sleep    " : "睡 觉   (  shuì jiào  )"
}; 
   var myKeys = [];   var myVals = []; var myOGGs= []; var myMP3s = []; var modKey;
   for(var aKey in o){
          aKey=aKey;
	  myKeys.push(aKey);
	  myVals.push(o[aKey]);
      modKey = aKey.trim().replace(/\,*\s+|\s+/g, '-'); // alert(modKey);
      myOGGs.push(modKey + '.ogg');
      myMP3s.push(modKey + '.mp3'); //alert(modKey+'.mp3');
   }
	 // var jj = 0;
	var counter = 0; // forwardFlag ? 0 : myKeys.length - 1;
	var keyFlag = false;  // forwardFlag ? false : true;
      function myFlasher(){
	   if(counter > myKeys.length - 1 ){
	      counter = 0;
	   }
	   if(counter < 0 ){
	       counter = myKeys.length - 1;
		}
//  11-20-2012  add code to change src of audio files ebr
// audio is in http://rockower.com/audio/audioDining
 //  $('#myOGG').attr('src', 'http://rockower.com/audio/audioDining/'+myOGGs[counter]); 
// alert('http://rockower.com/audio/audioDining/'+myOGGs[counter]);
 //  $('#myMP3').attr('src', 'http://rockower.com/audio/audioDining/'+myMP3s[counter]);
// page 50 html5 dummies
//function initSong(){
	   keyFlag = !keyFlag;
	   if(keyFlag){
	     // $("#flipbox").attr(color, red);
	      if(englishFirst){
     		  return {myContent: myKeys[counter], myColor: "#bbccbb"};
              } else {
   		      return {myContent : myVals[counter], myColor:"#bbccbb"};  //  myKeys[counter];
	       } 
	   } else {  // if keyFlag
            var song;    // MP3 if IE, Safari    // OGG if FF, Opera
            song = document.createElement('audio');
             song.setAttribute('preload', 'auto');  // preload="auto
// song.setAttribute('volume', '.05'); 
            if($.browser.msie || $.browser.webkit){  // IE or Safari
               song.setAttribute('src', '/audio/audioActivities/'+myMP3s[counter]);
  song.setAttribute('type', 'audio/mpeg');                    
            } else {
              song.setAttribute('src', '/audio/audioActivities/'+myOGGs[counter]);
            }   
             song.volume = .1;  
            song.play();
	       counter ++ ;   //  forwardFlag ? eval( 'counter ++'): eval( 'counter --');
	      if(englishFirst){
		       return {myContent: myVals[counter - 1], myColor : "green"}; 
          } else {
         	   return {myContent : myKeys[counter - 1], myColor : "green"};
		  }
	   }   // if keyFlag
	}
// </script>