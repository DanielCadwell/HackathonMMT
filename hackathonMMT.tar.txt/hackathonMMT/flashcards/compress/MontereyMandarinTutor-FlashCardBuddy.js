// this is MontereyMandarinTutor-FlashCardBuddy.js  10/18/2011 - 11/7 - 2/15/2012 Edward B. Rockower, Ph.D.
// was indexAjax.html 10-16-2011
 $(document).ready(function(){
   function trim(stringToTrim) {
    return stringToTrim.replace(/^\s+|\s+$/g,"");
   }
   function validEmail(email) {
	var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
   return re.test(email);
   }  // end validemail
   
  function validateFirstForm(){   // First Form to POST fields
    // var x=trim(document.forms["firstForm"]["email"].value);
    // if(x.length > 0 ){
   //  var isValidEmail= validEmail(x);
   //  if(! isValidEmail){
   //    alert('Please enter a valid email address');
   //    return false;
   //  } // end if is Valid email
 //  }  // end if x.length > 0
 
 /*
  var y=document.forms["firstForm"]["phone"].value;
  if ((x==null || x=="") && (y==null || y==""))
    {
    alert("Please enter an email address or telephone number \n so we can contact you");
    return false;
    }
*/
  edsValidatedForm = true;
  return true;
}  // end validateFirstForm
     var edsValidatedForm = false;
     var edsAlreadySubmitted = false;
	 var  edsAlreadySubmitted2 = false;
function edsChecker() {    				// 	  FUNCTION 	edsChecker()  
       if(true || ! edsAlreadySubmitted ) {
          edsValidatedForm = validateFirstForm();
        if (true || edsValidatedForm){
           edsAlreadySubmitted = true;
           $("#myResponse").load("/php/saveRedisJSON.php", $("#firstForm").serializeArray());
           $("#myResponse").animate({
              //    width:"200%",
                  fontSize:"17pt"
               //   fontColor: "red",
		 //   borderWidth:"11px"
            }, 2000);
           $("#myResponse").animate({
              //    width:"200%",
                  fontSize:"15pt"
               //   fontColor: "red",
            }, 2000);
var deckTitle = 'user:'+$('#user').val()+':'+$('#deckTitle').val();
           $("#decksList")
             .prepend('<option id="newDeck">'+deckTitle+"</option>");
            $('#newDeck').val($('#myJSON').val());
         //  .prepend('<option value=\"'+$('#myJSON').val()+'\">'+deckTitle+"</option>");
           document.getElementById("myResponse").style.backgroundColor='eeeeee';
        } // end if validated form
      } // end if already submitted
    }// end edsChecker fcn

 $("#myButton").bind('click',edsChecker);
});  // end ready