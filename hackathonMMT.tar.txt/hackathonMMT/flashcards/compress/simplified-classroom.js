// simplified-classroom.js
var theSong; var muteFlag = false; var myWord;
theSong = document.createElement('audio');
theSong.setAttribute('preload', 'auto');  // preload="auto
theSong.volume = .1;
			$(function(){	
				$("#flipPad a").bind("click",function(){
					var $this = $(this);
					// var myResults = [];
					var myResults = myFlasher();
					var myColor = myResults.myColor;
					var myContent = myResults.myContent;
					$("#flipbox").flip({
						direction:  $this.attr("rel"),
						color: myColor,  // "red",   // $this.attr("rev"),
						content: myContent    //  $this.attr("title"),//(new Date()).getTime(),
						//  onBefore: function(){$(".revert").show()}
					})
		   	                     return false;
				});	
			});   // end $.ready
    var englishFirst = true;
var o = Object();
o = {
"teacher    " : "老 师    (  lǎo shī   )",
"student    " : "学 生    (  xué shēng   )",
"student ID   " : "学 生 证    (  xué shēng zhèng   )",
"book bag, backpack    " : "书 包    (  shū bāo   )",
"desk    " : "书 桌    (  shū zhuō   )",
"chair    " : "椅 子    (  yǐ zi   )",
"whiteboard    " : "白 板    (  bái bǎn   )",
"computer    " : "电 脑    (  diàn nǎo   )",
"printer    " : "打 印 机    (  dă yìn jī   )",
"cell phone   " : "手 机    (  shǒu jī   )",
"dictionary    " : "字 典    (  zì diǎn   )",
"textbook    " : "课 本    (  kè běn   )",
"notebook -1    " : "本 子    (  běn zi   )",
"notebook -2    " : "笔 记 本    (  bǐ jì běn   )",
"paper    " : "纸    (  zhǐ   )",
"pen   " : "笔    (bǐ)",
"pencil    " : "铅 笔    (  qiān bǐ   )",
"eraser   " : "橡 皮   (  xìang pí  )",
"glue   " : "胶 水    (  jiāo shuǐ   )",
"tape   " : "胶 带    (  jiāo dài   )",
"scissors    " : "剪 刀    (  jiăn dāo   )",
"ruler    " : "尺    (  chĭ   )"
};
   var myKeys = [];   var myVals = []; var myOGGs= []; var myMP3s = []; var modKey;
   for(var aKey in o){
          aKey=aKey;
	  myKeys.push(aKey);
	  myVals.push(o[aKey]);
      modKey = aKey.trim().replace(/\,*\s+|\s+/g, '-'); // alert(modKey);
      myOGGs.push(modKey + '.ogg');
      myMP3s.push(modKey + '.mp3'); //alert(modKey+'.mp3');
   }
	 // var jj = 0;
	var counter = 0; // forwardFlag ? 0 : myKeys.length - 1;
	var keyFlag = false;  // forwardFlag ? false : true;
      function myFlasher(){
	   if(counter > myKeys.length - 1 ){
	      counter = 0;
	   }
	   if(counter < 0 ){
	       counter = myKeys.length - 1;
		}
	   keyFlag = !keyFlag;
	   if(keyFlag){
	     // $("#flipbox").attr(color, red);
	      if(englishFirst){
     		  return {myContent: myKeys[counter], myColor: "#bbccbb"};
              } else {
   		      return {myContent : myVals[counter], myColor:"#bbccbb"};  //  myKeys[counter];
	       } 
	   } else {  // if keyFlag
       //     var theSong;    // MP3 if IE, Safari    // OGG if FF, Opera
    //        theSong = document.createElement('audio');
     //        theSong.setAttribute('preload', 'auto');  // preload="auto
            if($.browser.msie || $.browser.webkit){  // IE or Safari
               theSong.setAttribute('src', '/audio/audioClassroom/'+myMP3s[counter]);
            } else {
              theSong.setAttribute('src', '/audio/audioClassroom/'+myOGGs[counter]);
            }   
           if(!muteFlag){ theSong.play(); }  // theSong = song;
	       counter ++ ;   //  forwardFlag ? eval( 'counter ++'): eval( 'counter --');
	      if(englishFirst){
		       return {myContent: myVals[counter - 1], myColor : "green"}; 
          } else {
         	   return {myContent : myKeys[counter - 1], myColor : "green"};
		  }
	   }   // if keyFlag
	}