//  traditional-family.js
var theSong; var muteFlag = false; var myWord;
theSong = document.createElement('audio');
theSong.setAttribute('preload', 'auto');  // preload="auto
theSong.volume = .1;
			$(function(){	
				$("#flipPad a").bind("click",function(){
					var $this = $(this);
					// var myResults = [];
					var myResults = myFlasher();
					var myColor = myResults.myColor;
					var myContent = myResults.myContent;
					$("#flipbox").flip({
						direction:  $this.attr("rel"),
						color: myColor,  // "red",   // $this.attr("rev"),
						content: myContent    //  $this.attr("title"),//(new Date()).getTime(),
						//  onBefore: function(){$(".revert").show()}
					})
		   	                     return false;
				});	
			});   // end $.ready
    var englishFirst = true;
var o = Object();
o = {
"dad" : "爸(bà) 爸(ba)",
 "mom" : "媽(mā) 媽(mā)",
 "older sister" : "姊(jiě) 姊(jiě)",
 "younger sister" : "妹(mèi) 妹(mèi)",
 "older brother" : "哥(gē) 哥(gē)",
 "younger brother" : "弟(dì) 弟(dì)",
 "grandpa" : "爺(yé) 爺(yé)",
 "grandma" : "奶(nǎi) 奶(nǎi)",
 "I, me" : "我(wǒ)",
 "we, us" : "我(wǒ) 們(men)",
 "you (singular)" : "你(nǐ)",
 "you (plural)" : "你(nǐ) 們(men)",
 "he, him" : "他(tā)",
 "she, her" : "她(tā)",
 "they, them" : "他(tā) 們(men)" 
};
//$.getScript('/json/DiningRoom.js');
   var myKeys = [];   var myVals = []; var myOGGs= []; var myMP3s = []; var modKey;
   for(var aKey in o){
          aKey=aKey;
	  myKeys.push(aKey);
	  myVals.push(o[aKey]);
      modKey = aKey.trim().replace(/\,*\s+|\s+/g, '-'); // alert(modKey);
      myOGGs.push(modKey + '.ogg');
      myMP3s.push(modKey + '.mp3'); //alert(modKey+'.mp3');
   }
	 // var jj = 0;
	var counter = 0; // forwardFlag ? 0 : myKeys.length - 1;
	var keyFlag = false;  // forwardFlag ? false : true;
      function myFlasher(){
	   if(counter > myKeys.length - 1 ){
	      counter = 0;
	   }
	   if(counter < 0 ){
	       counter = myKeys.length - 1;
		}
	   keyFlag = !keyFlag;
	   if(keyFlag){
	     // $("#flipbox").attr(color, red);
	      if(englishFirst){
     		  return {myContent: myKeys[counter], myColor: "#bbccbb"};
              } else {
   		      return {myContent : myVals[counter], myColor:"#bbccbb"};  //  myKeys[counter];
	       } 
	   } else {  // if keyFlag
       //     var theSong;    // MP3 if IE, Safari    // OGG if FF, Opera
    //        theSong = document.createElement('audio');
     //        theSong.setAttribute('preload', 'auto');  // preload="auto
            if($.browser.msie || $.browser.webkit){  // IE or Safari
               theSong.setAttribute('src', '/audio/audioFamily/'+myMP3s[counter]);
            } else {
              theSong.setAttribute('src', '/audio/audioFamily/'+myOGGs[counter]);
            }   
           if(!muteFlag){ theSong.play(); }  // theSong = song;
	       counter ++ ;   //  forwardFlag ? eval( 'counter ++'): eval( 'counter --');
	      if(englishFirst){
		       return {myContent: myVals[counter - 1], myColor : "green"}; 
          } else {
         	   return {myContent : myKeys[counter - 1], myColor : "green"};
		  }
	   }   // if keyFlag
	}