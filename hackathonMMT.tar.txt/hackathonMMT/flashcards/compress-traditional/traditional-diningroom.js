// traditional-diningroom.js
			$(function(){	
				$("#flipPad a").bind("click",function(){
					var $this = $(this);
					// var myResults = [];
					var myResults = myFlasher();
					var myColor = myResults.myColor;
					var myContent = myResults.myContent;
					$("#flipbox").flip({
						direction:  $this.attr("rel"),
						color: myColor,  // "red",   // $this.attr("rev"),
						content: myContent    //  $this.attr("title"),//(new Date()).getTime(),
						//  onBefore: function(){$(".revert").show()}
					})
		   	                     return false;
				});	
			});   // end $.ready
    var englishFirst = true;
var o = Object();
o = {
"dining room    " : "飯 廳    (  fàn tīng   )",   
"dining table    " : "飯 桌    (  fàn zhuō   )",
"chair    " : "椅 子    (  yǐ zi   )",
"cup, glass    " : "杯 子    (  bēi zi   )",
"plate    " : "盤 子    (  pán zi   )",
"fork   " : "叉 (子)    (  chā (zi)  )",
"chopsticks    " : "筷 子    (  kuài zi   )",
"bowl    " : "碗    (  wǎn   )",
"soup spoon    " : "湯 匙    (  tāng chí   )",
"napkin    " : "餐 巾    (  cān jīn   )"   
};
   var myKeys = [];   var myVals = []; var myOGGs= []; var myMP3s = []; var modKey;
   for(var aKey in o){
          aKey=aKey;
	  myKeys.push(aKey);
	  myVals.push(o[aKey]);
      modKey = aKey.trim().replace(/\,*\s+|\s+/, '-'); // alert(modKey);
      myOGGs.push(modKey + '.ogg');
      myMP3s.push(modKey + '.mp3'); //alert(modKey+'.mp3');
   }
	 // var jj = 0;
	var counter = 0; // forwardFlag ? 0 : myKeys.length - 1;
	var keyFlag = false;  // forwardFlag ? false : true;
      function myFlasher(){
	   if(counter > myKeys.length - 1 ){
	      counter = 0;
	   }
	   if(counter < 0 ){
	       counter = myKeys.length - 1;
		}
//  11-20-2012  add code to change src of audio files ebr
// audio is in http://rockower.com/audio/audioDining
 //  $('#myOGG').attr('src', 'http://rockower.com/audio/audioDining/'+myOGGs[counter]); 
// alert('http://rockower.com/audio/audioDining/'+myOGGs[counter]);
 //  $('#myMP3').attr('src', 'http://rockower.com/audio/audioDining/'+myMP3s[counter]);
// page 50 html5 dummies
//function initSong(){
	   keyFlag = !keyFlag;
	   if(keyFlag){
	     // $("#flipbox").attr(color, red);
	      if(englishFirst){
     		  return {myContent: myKeys[counter], myColor: "#bbccbb"};
              } else {
   		      return {myContent : myVals[counter], myColor:"#bbccbb"};  //  myKeys[counter];
	       } 
	   } else {  // if keyFlag
            var song;    // MP3 if IE, Safari    // OGG if FF, Opera
            song = document.createElement('audio');
             song.setAttribute('preload', 'auto');  // preload="auto
            if($.browser.msie || $.browser.webkit){  // IE or Safari
               song.setAttribute('src', '/audio/audioDiningRoom/'+myMP3s[counter]);
            } else {
              song.setAttribute('src', '/audio/audioDiningRoom/'+myOGGs[counter]);
            }   
            song.play();
	       counter ++ ;   //  forwardFlag ? eval( 'counter ++'): eval( 'counter --');
	      if(englishFirst){
		       return {myContent: myVals[counter - 1], myColor : "green"}; 
          } else {
         	   return {myContent : myKeys[counter - 1], myColor : "green"};
		  }
	   }   // if keyFlag
	}