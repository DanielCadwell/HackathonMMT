java -jar yuicompressor-2.4.7.jar -o $1.min.js $1
