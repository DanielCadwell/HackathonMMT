java -jar /opt/yuicompressor-2.4.7.jar -o '.js$:-min.js' *.js

